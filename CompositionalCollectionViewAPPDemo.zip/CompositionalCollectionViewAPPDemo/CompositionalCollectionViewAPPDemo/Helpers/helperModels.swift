//
//  helperModels.swift
//  CompositionalCollectionViewAPPDemo
//
//  Created by iMac on 14/09/22.
//

import Foundation
import UIKit

struct ItemModel{
    var pdImage:String
    var pdName:String
    
        init(pdImage:String,pdName:String){
            self.pdImage = pdImage
            self.pdName = pdName
        }
}
